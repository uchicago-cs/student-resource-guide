print("hola!")
print("hola, mundo!")
print("hola, universo!")

