print("Hello!")
print("Hello, world!")
print("Hello, universe!")

